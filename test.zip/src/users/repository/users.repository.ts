import { EntityRepository, Repository } from 'typeorm';
import { Users } from '../../db/entities';
import { CreateUserDto } from '../dto/user.dto';

@EntityRepository(Users)
export class UsersRepository extends Repository<Users> {
  async add_user(createTaskDto: CreateUserDto): Promise<Users> {
    const { user_name, user_surname } = createTaskDto;
    const user = new Users();
    user.user_name = user_name;
    user.user_surname = user_surname;
    await user.save();
    return user;
  }
}
