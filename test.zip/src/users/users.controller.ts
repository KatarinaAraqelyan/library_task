import {
  Body,
  Controller,
  Post,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/user.dto';
import { Users } from '../db/entities';

@Controller('users')
export class UsersController {
  constructor(private usersService: UsersService) {}
  @Post()
  @UsePipes(ValidationPipe)
  createTask(@Body() user: CreateUserDto): Promise<Users> {
    return this.usersService.add_user(user);
  }
}
